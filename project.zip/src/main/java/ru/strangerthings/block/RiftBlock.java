package ru.strangerthings.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import ru.strangerthings.Teleporter;

/** Разлом (Врата): шагни внутрь — попадёшь в Изнанку (и обратно). */
public class RiftBlock extends Block {
    public static final MapCodec<RiftBlock> CODEC = createCodec(RiftBlock::new);

    public RiftBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return CODEC;
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world instanceof ServerWorld sw && entity instanceof PlayerEntity && !entity.hasPortalCooldown()) {
            entity.setPortalCooldown(300);
            sw.getServer().execute(() -> Teleporter.riftTravel(entity, sw, pos));
        }
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        world.addParticle(ParticleTypes.ASH, pos.getX() + random.nextDouble(), pos.getY() + 1.0,
                pos.getZ() + random.nextDouble(), 0, 0.05, 0);
    }
}
