package ru.strangerthings.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.strangerthings.Teleporter;

/** Бассейн изоляции: ПКМ — уйти в Измерение Х (Пустоту Оди). */
public class VoidPoolBlock extends Block {
    public static final MapCodec<VoidPoolBlock> CODEC = createCodec(VoidPoolBlock::new);

    public VoidPoolBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return CODEC;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world instanceof ServerWorld sw && player instanceof ServerPlayerEntity sp) {
            Teleporter.voidTravel(sp, sw);
        }
        return ActionResult.SUCCESS;
    }
}
