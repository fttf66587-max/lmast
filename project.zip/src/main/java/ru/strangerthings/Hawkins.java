package ru.strangerthings;

import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Генерация города Хоукинс и лаборатории (строится один раз при первом визите). */
public final class Hawkins {
    static final int GY = 4; // высота земли (верхний блок травы)

    private Hawkins() {}

    public static void enter(ServerPlayerEntity p) {
        ServerWorld w = p.getServer().getWorld(Teleporter.HAWKINS);
        if (w == null) {
            p.sendMessage(Text.literal("Измерение Хоукинса не загружено — перезайдите в мир."), false);
            return;
        }
        if (!w.getBlockState(new BlockPos(0, GY, 0)).isOf(Blocks.IRON_BLOCK)) {
            p.sendMessage(Text.literal("Строим Хоукинс... подождите пару секунд."), true);
            build(w);
        }
        p.setSpawnPoint(Teleporter.HAWKINS, new BlockPos(0, GY + 1, 6), 0f, true, false);
        Teleporter.teleport(p, w, new Vec3d(0.5, GY + 1, 6.5));
        p.sendMessage(Text.literal("Добро пожаловать в Хоукинс, Индиана. 1984 год."), true);
    }

    // ---------- helpers ----------
    static void fill(ServerWorld w, int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        BlockState s = b.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    w.setBlockState(m.set(x, y, z), s, Block.NOTIFY_LISTENERS);
    }

    static void set(ServerWorld w, int x, int y, int z, BlockState s) {
        w.setBlockState(new BlockPos(x, y, z), s, Block.NOTIFY_LISTENERS);
    }

    static void door(ServerWorld w, int x, int y, int z, Direction f) {
        BlockState d = Blocks.SPRUCE_DOOR.getDefaultState().with(DoorBlock.FACING, f);
        set(w, x, y, z, d.with(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        set(w, x, y + 1, z, d.with(DoorBlock.HALF, DoubleBlockHalf.UPPER));
    }

    static void label(ServerWorld w, double x, double y, double z, String text) {
        ArmorStandEntity a = EntityType.ARMOR_STAND.spawn(w, BlockPos.ofFloored(x, y, z), SpawnReason.STRUCTURE);
        if (a == null) return;
        a.setPosition(x, y, z);
        a.setInvisible(true);
        a.setNoGravity(true);
        a.setInvulnerable(true);
        a.setCustomName(Text.literal(text));
        a.setCustomNameVisible(true);
    }

    static <T extends MobEntity> void npc(ServerWorld w, EntityType<T> t, double x, int y, double z) {
        T m = t.spawn(w, BlockPos.ofFloored(x, y, z), SpawnReason.STRUCTURE);
        if (m != null) m.setPersistent();
    }

    static void house(ServerWorld w, int x1, int z1, int x2, int z2, Block wall, boolean doorMinZ, String name) {
        int y0 = GY + 1, h = 4;
        fill(w, x1, GY, z1, x2, GY, z2, Blocks.SPRUCE_PLANKS);
        fill(w, x1, y0, z1, x2, y0 + h - 1, z2, wall);
        fill(w, x1 + 1, y0, z1 + 1, x2 - 1, y0 + h - 1, z2 - 1, Blocks.AIR);
        fill(w, x1 - 1, y0 + h, z1 - 1, x2 + 1, y0 + h, z2 + 1, Blocks.DARK_OAK_PLANKS);
        int dx = (x1 + x2) / 2;
        int dz = doorMinZ ? z1 : z2;
        door(w, dx, y0, dz, doorMinZ ? Direction.NORTH : Direction.SOUTH);
        int mz = (z1 + z2) / 2;
        fill(w, x1, y0 + 1, mz, x1, y0 + 2, mz, Blocks.GLASS);
        fill(w, x2, y0 + 1, mz, x2, y0 + 2, mz, Blocks.GLASS);
        fill(w, x1 + 2, y0 + 1, doorMinZ ? z2 : z1, x1 + 3, y0 + 2, doorMinZ ? z2 : z1, Blocks.GLASS);
        set(w, x1 + 1, y0, z1 + 1, Blocks.CRAFTING_TABLE.getDefaultState());
        set(w, x2 - 1, y0, z2 - 1, Blocks.LANTERN.getDefaultState());
        set(w, x1 + 1, y0 + 2, z2 - 1, ModBlocks.CHRISTMAS_LIGHTS.getDefaultState());
        label(w, dx + 0.5, y0 + 3.2, dz + (doorMinZ ? -1 : 1) + 0.5, "§6" + name);
    }

    // ---------- build ----------
    static void build(ServerWorld w) {
        // Дороги
        fill(w, -60, GY, -3, 60, GY, 3, Blocks.GRAY_CONCRETE);
        fill(w, -3, GY, -41, 3, GY, 40, Blocks.GRAY_CONCRETE);
        fill(w, -60, GY, -4, 60, GY, -4, Blocks.SMOOTH_STONE);
        fill(w, -60, GY, 4, 60, GY, 4, Blocks.SMOOTH_STONE);
        for (int x = -60; x <= 60; x++) if (Math.floorMod(x, 4) < 2) set(w, x, GY, 0, Blocks.YELLOW_CONCRETE.getDefaultState());
        set(w, 0, GY, 0, Blocks.IRON_BLOCK.getDefaultState()); // метка «город построен»

        // Фонари
        for (int x = -48; x <= 48; x += 16) for (int z : new int[]{-5, 5}) {
            fill(w, x, GY + 1, z, x, GY + 4, z, Blocks.OAK_FENCE);
            set(w, x, GY + 5, z, Blocks.LANTERN.getDefaultState());
        }

        // Дома и здания
        house(w, -22, 10, -12, 18, Blocks.SPRUCE_PLANKS, true, "Дом Байерсов");
        house(w, 12, 10, 22, 18, Blocks.BRICKS, true, "Дом Уилеров");
        house(w, -26, -20, -18, -12, Blocks.STRIPPED_SPRUCE_LOG, false, "Хижина Хоппера");
        house(w, 12, -20, 24, -12, Blocks.LIGHT_BLUE_CONCRETE, false, "Scoops Ahoy");
        house(w, -12, -18, -6, -12, Blocks.RED_TERRACOTTA, false, "Palace Arcade");
        house(w, 28, 10, 44, 24, Blocks.BRICKS, true, "Школа Хоукинса");
        label(w, 0.5, GY + 4, 7.5, "§c§lХОУКИНС, ИНДИАНА");

        buildLab(w);

        // Герои
        npc(w, ModEntities.ELEVEN, -9.5, GY + 1, -46.5);
        npc(w, ModEntities.MIKE, 16.5, GY + 1, 8.5);
        npc(w, ModEntities.WILL, -16.5, GY + 1, 8.5);
        npc(w, ModEntities.DUSTIN, 5.5, GY + 1, 6.5);
        npc(w, ModEntities.LUCAS, 7.5, GY + 1, 6.5);
        npc(w, ModEntities.STEVE, 18.5, GY + 1, -9.5);
        npc(w, ModEntities.HOPPER, -22.5, GY + 1, -10.5);
        // Обычные жители
        for (int i = 0; i < 8; i++) npc(w, EntityType.VILLAGER, -20 + i * 6 + 0.5, GY + 1, 5.5 + (i % 2) * 2);
    }

    static void buildLab(ServerWorld w) {
        int y0 = GY + 1;
        fill(w, -16, GY, -62, 16, GY, -42, Blocks.WHITE_CONCRETE);
        fill(w, -16, y0, -62, 16, y0 + 10, -42, Blocks.LIGHT_GRAY_CONCRETE);
        fill(w, -15, y0, -61, 15, y0 + 9, -43, Blocks.AIR);
        fill(w, -2, y0, -42, 2, y0 + 3, -42, Blocks.AIR); // вход
        for (int x = -12; x <= 12; x += 6) for (int z = -58; z <= -46; z += 6)
            set(w, x, y0 + 9, z, Blocks.SEA_LANTERN.getDefaultState());
        // Внутренняя стена с проёмом
        fill(w, -15, y0, -52, 15, y0 + 9, -52, Blocks.WHITE_CONCRETE);
        fill(w, -1, y0, -52, 1, y0 + 3, -52, Blocks.AIR);
        // Камера Оди
        fill(w, -12, y0, -49, -8, y0 + 3, -45, Blocks.IRON_BARS);
        fill(w, -11, y0, -48, -9, y0 + 3, -46, Blocks.AIR);
        fill(w, -10, y0, -45, -10, y0 + 1, -45, Blocks.AIR);
        // Сундуки с лутом
        set(w, 10, y0, -46, Blocks.CHEST.getDefaultState());
        set(w, 12, y0, -46, Blocks.CHEST.getDefaultState());
        BlockEntity c1 = w.getBlockEntity(new BlockPos(10, y0, -46));
        if (c1 instanceof ChestBlockEntity c) {
            c.setStack(0, new ItemStack(ModItems.EGGO, 12));
            c.setStack(1, new ItemStack(ModItems.KEYCARD, 2));
            c.setStack(2, new ItemStack(ModItems.WALKIE_TALKIE, 2));
        }
        BlockEntity c2 = w.getBlockEntity(new BlockPos(12, y0, -46));
        if (c2 instanceof ChestBlockEntity c) {
            c.setStack(0, new ItemStack(ModItems.NAIL_BAT, 1));
            c.setStack(1, new ItemStack(ModItems.WRIST_ROCKET, 1));
            c.setStack(2, new ItemStack(Items.IRON_NUGGET, 32));
            c.setStack(3, new ItemStack(ModItems.D20, 3));
        }
        // Комната Врат: разлом в Изнанку, окружённый плотью
        fill(w, -4, GY, -60, 4, GY, -54, Blocks.WHITE_CONCRETE);
        fill(w, -3, GY, -60, 3, GY, -55, ModBlocks.UPSIDE_FLESH);
        fill(w, -3, y0, -60, 3, y0 + 4, -60, ModBlocks.UPSIDE_FLESH);
        set(w, 0, y0, -58, ModBlocks.RIFT.getDefaultState());
        set(w, -2, y0, -58, ModBlocks.CHRISTMAS_LIGHTS.getDefaultState());
        set(w, 2, y0, -58, ModBlocks.CHRISTMAS_LIGHTS.getDefaultState());
        label(w, 0.5, y0 + 4, -41.5, "§fHawkins National Laboratory");
        label(w, 0.5, y0 + 2, -57.5, "§4Врата");
    }
}
