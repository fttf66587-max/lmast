package ru.strangerthings;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.Heightmap;
import ru.strangerthings.entity.*;

public final class ModEntities {
    public static final EntityType<DemogorgonEntity> DEMOGORGON = reg("demogorgon",
            EntityType.Builder.create(DemogorgonEntity::new, SpawnGroup.MONSTER).dimensions(0.8f, 2.4f));
    public static final EntityType<DemodogEntity> DEMODOG = reg("demodog",
            EntityType.Builder.create(DemodogEntity::new, SpawnGroup.MONSTER).dimensions(0.9f, 0.9f));
    public static final EntityType<VecnaEntity> VECNA = reg("vecna",
            EntityType.Builder.create(VecnaEntity::new, SpawnGroup.MONSTER).dimensions(0.9f, 2.7f).maxTrackingRange(10));
    public static final EntityType<MindFlayerEntity> MIND_FLAYER = reg("mind_flayer",
            EntityType.Builder.create(MindFlayerEntity::new, SpawnGroup.MONSTER).dimensions(4.0f, 3.2f).maxTrackingRange(12));

    public static final EntityType<CharacterEntity> ELEVEN = hero("eleven", Hero.ELEVEN);
    public static final EntityType<CharacterEntity> MIKE = hero("mike", Hero.MIKE);
    public static final EntityType<CharacterEntity> STEVE = hero("steve", Hero.STEVE);
    public static final EntityType<CharacterEntity> HOPPER = hero("hopper", Hero.HOPPER);
    public static final EntityType<CharacterEntity> DUSTIN = hero("dustin", Hero.DUSTIN);
    public static final EntityType<CharacterEntity> WILL = hero("will", Hero.WILL);
    public static final EntityType<CharacterEntity> LUCAS = hero("lucas", Hero.LUCAS);

    private static <T extends Entity> EntityType<T> reg(String name, EntityType.Builder<T> b) {
        RegistryKey<EntityType<?>> key = RegistryKey.of(RegistryKeys.ENTITY_TYPE, StrangerThings.id(name));
        return Registry.register(Registries.ENTITY_TYPE, key, b.build(key));
    }

    private static EntityType<CharacterEntity> hero(String name, Hero hero) {
        return reg(name, EntityType.Builder.<CharacterEntity>create((t, w) -> new CharacterEntity(t, w, hero), SpawnGroup.CREATURE)
                .dimensions(0.6f, 1.8f));
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(DEMOGORGON, DemogorgonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMODOG, DemodogEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(VECNA, VecnaEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIND_FLAYER, MindFlayerEntity.createAttributes());
        for (EntityType<CharacterEntity> t : new EntityType[]{ELEVEN, MIKE, STEVE, HOPPER, DUSTIN, WILL, LUCAS})
            FabricDefaultAttributeRegistry.register(t, CharacterEntity.createAttributes());

        SpawnRestriction.register(DEMOGORGON, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(DEMODOG, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
    }
}
