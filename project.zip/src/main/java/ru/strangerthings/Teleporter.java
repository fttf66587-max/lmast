package ru.strangerthings;

import net.minecraft.entity.Entity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;

public final class Teleporter {
    public static final RegistryKey<World> UPSIDE_DOWN = RegistryKey.of(RegistryKeys.WORLD, StrangerThings.id("upside_down"));
    public static final RegistryKey<World> HAWKINS = RegistryKey.of(RegistryKeys.WORLD, StrangerThings.id("hawkins"));
    public static final RegistryKey<World> VOID = RegistryKey.of(RegistryKeys.WORLD, StrangerThings.id("the_void"));

    private Teleporter() {}

    public static void teleport(Entity e, ServerWorld w, Vec3d pos) {
        e.teleportTo(new TeleportTarget(w, pos, Vec3d.ZERO, e.getYaw(), e.getPitch(), TeleportTarget.NO_OP));
    }

    /** Разлом: Обычный мир <-> Изнанка (те же координаты X/Z). */
    public static void riftTravel(Entity entity, ServerWorld from, BlockPos pos) {
        MinecraftServer server = from.getServer();
        RegistryKey<World> destKey = from.getRegistryKey().equals(UPSIDE_DOWN) ? World.OVERWORLD : UPSIDE_DOWN;
        ServerWorld dest = server.getWorld(destKey);
        if (dest == null) return;
        BlockPos ground = dest.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, pos);
        BlockPos mark = dest.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, ground.east(3));
        dest.setBlockState(mark, ModBlocks.RIFT.getDefaultState());
        teleport(entity, dest, Vec3d.ofBottomCenter(ground));
    }

    /** Бассейн изоляции: Измерение Х (Пустота Оди) <-> Обычный мир. */
    public static void voidTravel(ServerPlayerEntity p, ServerWorld from) {
        MinecraftServer server = from.getServer();
        if (from.getRegistryKey().equals(VOID)) {
            toOverworld(p);
            return;
        }
        ServerWorld v = server.getWorld(VOID);
        if (v == null) {
            p.sendMessage(Text.literal("Измерение Х ещё не загружено — перезайдите в мир."), false);
            return;
        }
        v.setBlockState(new BlockPos(3, 1, 0), ModBlocks.VOID_POOL.getDefaultState());
        teleport(p, v, new Vec3d(0.5, 1, 0.5));
        p.sendMessage(Text.literal("Ты в Измерении Х. Тишина... Найди бассейн, чтобы вернуться."), true);
    }

    public static void toOverworld(ServerPlayerEntity p) {
        ServerWorld ow = p.getServer().getOverworld();
        BlockPos top = ow.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, ow.getSpawnPos());
        p.setSpawnPoint(World.OVERWORLD, null, 0f, false, false);
        teleport(p, ow, Vec3d.ofBottomCenter(top));
    }

    public static void toUpsideDown(ServerPlayerEntity p) {
        ServerWorld d = p.getServer().getWorld(UPSIDE_DOWN);
        if (d == null) {
            p.sendMessage(Text.literal("Изнанка не загружена — перезайдите в мир."), false);
            return;
        }
        BlockPos top = d.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, p.getBlockPos());
        teleport(p, d, Vec3d.ofBottomCenter(top));
    }

    public static void toVoid(ServerPlayerEntity p) {
        voidTravel(p, p.getServerWorld());
    }
}
