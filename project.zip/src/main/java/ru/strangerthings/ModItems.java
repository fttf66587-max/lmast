package ru.strangerthings;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import ru.strangerthings.item.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class ModItems {
    public static final List<Item> ALL = new ArrayList<>();

    public static final Item EGGO = reg("eggo", Item::new,
            new Item.Settings().food(new FoodComponent.Builder().nutrition(5).saturationModifier(0.6f).build()));
    public static final Item NAIL_BAT = reg("nail_bat", Item::new, new Item.Settings().sword(ToolMaterial.IRON, 4f, -2.4f));
    public static final Item WRIST_ROCKET = reg("wrist_rocket", WristRocketItem::new, new Item.Settings().maxDamage(250));
    public static final Item WALKIE_TALKIE = reg("walkie_talkie", WalkieTalkieItem::new, new Item.Settings().maxCount(1));
    public static final Item D20 = reg("d20_dice", DiceItem::new, new Item.Settings().maxCount(16));
    public static final Item ELEVEN_POWER = reg("eleven_power", ElevenPowerItem::new, new Item.Settings().maxCount(1));
    public static final Item RIFT_KEY = reg("rift_key", RiftKeyItem::new, new Item.Settings().maxDamage(16));
    public static final Item VECNA_CLOCK = reg("vecna_clock", VecnaClockItem::new, new Item.Settings().maxCount(1));
    public static final Item KEYCARD = reg("hawkins_keycard", Item::new, new Item.Settings());

    public static final Item DEMOGORGON_EGG = egg("demogorgon", ModEntities.DEMOGORGON);
    public static final Item DEMODOG_EGG = egg("demodog", ModEntities.DEMODOG);
    public static final Item VECNA_EGG = egg("vecna", ModEntities.VECNA);
    public static final Item MIND_FLAYER_EGG = egg("mind_flayer", ModEntities.MIND_FLAYER);
    public static final Item ELEVEN_EGG = egg("eleven", ModEntities.ELEVEN);
    public static final Item MIKE_EGG = egg("mike", ModEntities.MIKE);
    public static final Item STEVE_EGG = egg("steve", ModEntities.STEVE);
    public static final Item HOPPER_EGG = egg("hopper", ModEntities.HOPPER);
    public static final Item DUSTIN_EGG = egg("dustin", ModEntities.DUSTIN);
    public static final Item WILL_EGG = egg("will", ModEntities.WILL);
    public static final Item LUCAS_EGG = egg("lucas", ModEntities.LUCAS);

    private static <T extends Item> T reg(String name, Function<Item.Settings, T> f, Item.Settings s) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, StrangerThings.id(name));
        T item = Registry.register(Registries.ITEM, key, f.apply(s.registryKey(key)));
        ALL.add(item);
        return item;
    }

    private static Item egg(String name, EntityType<? extends MobEntity> type) {
        return reg(name + "_spawn_egg", s -> new SpawnEggItem(type, s), new Item.Settings());
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(NAIL_BAT))
                .displayName(Text.translatable("itemGroup.strangerthings.main"))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build();
        Registry.register(Registries.ITEM_GROUP, RegistryKey.of(RegistryKeys.ITEM_GROUP, StrangerThings.id("main")), group);
    }
}
