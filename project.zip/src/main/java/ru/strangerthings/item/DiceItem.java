package ru.strangerthings.item;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Кубик d20 из D&D: 20 — героический успех, 1 — критический провал. */
public class DiceItem extends Item {
    public DiceItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient) {
            int roll = world.random.nextInt(20) + 1;
            String comment;
            if (roll == 20) {
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 1));
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 400, 1));
                comment = "§6КРИТИЧЕСКИЙ УСПЕХ!";
            } else if (roll == 1) {
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 600, 1));
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 600, 0));
                comment = "§4Критический провал...";
            } else if (roll >= 15) {
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 1));
                comment = "§aУдача!";
            } else if (roll <= 5) {
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 300, 0));
                comment = "§cНе повезло.";
            } else {
                comment = "§7Обычный бросок.";
            }
            user.sendMessage(Text.literal("🎲 d20: §e" + roll + " " + comment), false);
        }
        user.getItemCooldownManager().set(user.getStackInHand(hand), 40);
        return ActionResult.SUCCESS;
    }
}
