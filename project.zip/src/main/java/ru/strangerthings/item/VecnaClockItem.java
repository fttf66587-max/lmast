package ru.strangerthings.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.entity.SpawnReason;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import ru.strangerthings.ModEntities;

/** Часы Векны: ПКМ по земле — призывают Векну. Используй осторожно. */
public class VecnaClockItem extends Item {
    public VecnaClockItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (ctx.getWorld() instanceof ServerWorld sw) {
            BlockPos p = ctx.getBlockPos().up();
            ModEntities.VECNA.spawn(sw, p, SpawnReason.MOB_SUMMONED);
            sw.playSound(null, p, SoundEvents.BLOCK_BELL_USE, SoundCategory.HOSTILE, 3f, 0.5f);
            ctx.getStack().decrementUnlessCreative(1, ctx.getPlayer());
        }
        return ActionResult.SUCCESS;
    }
}
