package ru.strangerthings.item;

import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import ru.strangerthings.entity.UpsideDownMob;

/** Рация: сообщает, сколько тварей Изнанки рядом (радиус 40). */
public class WalkieTalkieItem extends Item {
    private static final String[] LINES = {
            "Майк: Оди, ты слышишь? Приём!", "Дастин: Это Дастин! Тут что-то есть, приём!",
            "Лукас: Проверка связи, как слышно?", "Хоппер: Всем оставаться на местах."};

    public WalkieTalkieItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient) {
            long n = world.getEntitiesByClass(HostileEntity.class, user.getBoundingBox().expand(40), e -> e instanceof UpsideDownMob).size();
            String line = LINES[world.random.nextInt(LINES.length)];
            user.sendMessage(Text.literal(line + (n > 0 ? "  §c[Тварей рядом: " + n + "]" : "  §a[Чисто]")), false);
        }
        user.getItemCooldownManager().set(user.getStackInHand(hand), 20);
        return ActionResult.SUCCESS;
    }
}
