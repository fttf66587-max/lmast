package ru.strangerthings.item;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Рогатка Дастина/Лукаса: стреляет железными самородками (боеприпас). */
public class WristRocketItem extends Item {
    public WristRocketItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        boolean creative = user.isCreative();
        int slot = -1;
        if (!creative) {
            for (int i = 0; i < user.getInventory().size(); i++) {
                if (user.getInventory().getStack(i).isOf(Items.IRON_NUGGET)) { slot = i; break; }
            }
            if (slot < 0) return ActionResult.FAIL;
        }
        if (world instanceof ServerWorld sw) {
            ArrowEntity a = new ArrowEntity(sw, user, new ItemStack(Items.ARROW), stack);
            a.setVelocity(user, user.getPitch(), user.getYaw(), 0f, 2.8f, 1f);
            sw.spawnEntity(a);
            if (!creative) {
                user.getInventory().getStack(slot).decrement(1);
                stack.damage(1, user, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
            }
            sw.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1f, 1.6f);
        }
        user.getItemCooldownManager().set(stack, 12);
        return ActionResult.SUCCESS;
    }
}
