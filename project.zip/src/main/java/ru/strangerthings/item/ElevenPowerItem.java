package ru.strangerthings.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Сила Оди: телекинетический удар вперёд. Цена — кровь из носа (урон и голод). */
public class ElevenPowerItem extends Item {
    public ElevenPowerItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world instanceof ServerWorld sw) {
            Vec3d dir = user.getRotationVec(1f);
            Box box = user.getBoundingBox().stretch(dir.multiply(14)).expand(3);
            for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, box, x -> x != user && x.isAlive())) {
                e.takeKnockback(2.2, -dir.x, -dir.z);
                e.addVelocity(0, 0.5, 0);
                e.damage(sw, sw.getDamageSources().magic(), 6f);
                sw.spawnParticles(ParticleTypes.ENCHANT, e.getX(), e.getBodyY(0.5), e.getZ(), 20, 0.4, 0.5, 0.4, 0.2);
            }
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 160, 1));
            user.damage(sw, sw.getDamageSources().magic(), 1f);
            sw.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 0.6f, 1.4f);
        }
        user.getItemCooldownManager().set(user.getStackInHand(hand), 80);
        return ActionResult.SUCCESS;
    }
}
