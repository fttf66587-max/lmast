package ru.strangerthings.item;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.strangerthings.ModBlocks;

/** Ключ от Врат: открывает Разлом в Изнанку на выбранной поверхности. */
public class RiftKeyItem extends Item {
    public RiftKeyItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
        if (!world.getBlockState(pos).isReplaceable()) return ActionResult.FAIL;
        if (!world.isClient) {
            world.setBlockState(pos, ModBlocks.RIFT.getDefaultState());
            world.playSound(null, pos, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 0.7f, 0.6f);
            PlayerEntity p = ctx.getPlayer();
            if (p != null) ctx.getStack().damage(1, p, EquipmentSlot.MAINHAND);
        }
        return ActionResult.SUCCESS;
    }
}
