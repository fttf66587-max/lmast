package ru.strangerthings.client;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.SpiderEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Демопёс и Пожиратель разума на модели паука (заглушка до появления своих моделей). */
public class SpiderLikeRenderer<T extends MobEntity> extends MobEntityRenderer<T, LivingEntityRenderState, SpiderEntityModel> {
    private final Identifier texture;
    private final float scale;

    public SpiderLikeRenderer(EntityRendererFactory.Context ctx, Identifier texture, float scale) {
        super(ctx, new SpiderEntityModel(ctx.getPart(EntityModelLayers.SPIDER)), 0.8f * scale);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTexture(LivingEntityRenderState state) {
        return texture;
    }

    @Override
    protected void scale(LivingEntityRenderState state, MatrixStack matrices) {
        matrices.scale(scale, scale, scale);
    }
}
