package ru.strangerthings.client;

import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Identifier;
import ru.strangerthings.entity.CharacterEntity;

/** Герои сериала: модель игрока Steve + свой скин. */
public class CharacterRenderer extends BipedEntityRenderer<CharacterEntity, PlayerEntityRenderState, PlayerEntityModel> {
    private final Identifier texture;

    public CharacterRenderer(EntityRendererFactory.Context ctx, Identifier texture) {
        super(ctx, new PlayerEntityModel(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        this.texture = texture;
    }

    @Override
    public PlayerEntityRenderState createRenderState() {
        return new PlayerEntityRenderState();
    }

    @Override
    public Identifier getTexture(PlayerEntityRenderState state) {
        return texture;
    }
}
