package ru.strangerthings.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.util.Identifier;
import ru.strangerthings.ModEntities;
import ru.strangerthings.StrangerThings;

public class StrangerThingsClient implements ClientModInitializer {
    private static Identifier tex(String n) {
        return StrangerThings.id("textures/entity/" + n + ".png");
    }

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.DEMOGORGON, ctx -> new HumanoidRenderer<>(ctx, tex("demogorgon"), 1.25f));
        EntityRendererRegistry.register(ModEntities.VECNA, ctx -> new HumanoidRenderer<>(ctx, tex("vecna"), 1.5f));
        EntityRendererRegistry.register(ModEntities.DEMODOG, ctx -> new SpiderLikeRenderer<>(ctx, tex("demodog"), 0.9f));
        EntityRendererRegistry.register(ModEntities.MIND_FLAYER, ctx -> new SpiderLikeRenderer<>(ctx, tex("mind_flayer"), 3.2f));

        EntityRendererRegistry.register(ModEntities.ELEVEN, ctx -> new CharacterRenderer(ctx, tex("eleven")));
        EntityRendererRegistry.register(ModEntities.MIKE, ctx -> new CharacterRenderer(ctx, tex("mike")));
        EntityRendererRegistry.register(ModEntities.STEVE, ctx -> new CharacterRenderer(ctx, tex("steve")));
        EntityRendererRegistry.register(ModEntities.HOPPER, ctx -> new CharacterRenderer(ctx, tex("hopper")));
        EntityRendererRegistry.register(ModEntities.DUSTIN, ctx -> new CharacterRenderer(ctx, tex("dustin")));
        EntityRendererRegistry.register(ModEntities.WILL, ctx -> new CharacterRenderer(ctx, tex("will")));
        EntityRendererRegistry.register(ModEntities.LUCAS, ctx -> new CharacterRenderer(ctx, tex("lucas")));
    }
}
