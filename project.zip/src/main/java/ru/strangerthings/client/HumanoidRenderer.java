package ru.strangerthings.client;

import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.client.render.entity.state.ZombieEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Гуманоидные монстры (Демогоргон, Векна) на модели зомби с кастомной текстурой и масштабом. */
public class HumanoidRenderer<T extends MobEntity>
        extends BipedEntityRenderer<T, ZombieEntityRenderState, ZombieEntityModel<ZombieEntityRenderState>> {
    private final Identifier texture;
    private final float scale;

    public HumanoidRenderer(EntityRendererFactory.Context ctx, Identifier texture, float scale) {
        super(ctx, new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f * scale);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public ZombieEntityRenderState createRenderState() {
        return new ZombieEntityRenderState();
    }

    @Override
    public Identifier getTexture(ZombieEntityRenderState state) {
        return texture;
    }

    @Override
    protected void scale(ZombieEntityRenderState state, MatrixStack matrices) {
        matrices.scale(scale, scale, scale);
    }
}
