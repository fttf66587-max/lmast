package ru.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import ru.strangerthings.ModItems;

/** Дружелюбный герой сериала. Защищает игрока от тварей Изнанки. */
public class CharacterEntity extends PathAwareEntity {
    private final Hero hero;

    public CharacterEntity(EntityType<? extends CharacterEntity> type, World world, Hero hero) {
        super(type, world);
        this.hero = hero;
        getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(hero.health);
        getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(hero.damage);
        getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(hero.speed);
        setHealth(hero.health);
        setPersistent();
        if (hero == Hero.STEVE) equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.NAIL_BAT));
        if (hero == Hero.LUCAS || hero == Hero.DUSTIN) equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.WRIST_ROCKET));
        if (hero == Hero.MIKE) equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.WALKIE_TALKIE));
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20)
                .add(EntityAttributes.ATTACK_DAMAGE, 3)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.FOLLOW_RANGE, 24);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.add(2, new WanderAroundGoal(this, 0.8));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        goalSelector.add(4, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, MobEntity.class, 5, true, false, (t, w) -> t instanceof UpsideDownMob));
    }

    @Override
    public void tick() {
        super.tick();
        // Оди: телекинез по цели
        if (hero == Hero.ELEVEN && !getWorld().isClient && age % 40 == 0) {
            LivingEntity t = getTarget();
            if (t != null && t.isAlive() && squaredDistanceTo(t) < 225) {
                ServerWorld sw = (ServerWorld) getWorld();
                t.addVelocity(0, 0.9, 0);
                t.damage(sw, getDamageSources().magic(), 8f);
                sw.spawnParticles(ParticleTypes.ENCHANT, t.getX(), t.getBodyY(0.5), t.getZ(), 25, 0.4, 0.5, 0.4, 0.3);
            }
        }
    }

    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (getWorld().isClient) return ActionResult.SUCCESS;
        ItemStack held = player.getStackInHand(hand);
        if (held.isOf(ModItems.EGGO)) {
            held.decrementUnlessCreative(1, player);
            heal(8f);
            player.sendMessage(Text.literal("§e" + hero.title + ": §fЭгго!"), false);
            return ActionResult.SUCCESS;
        }
        String line = hero.lines[random.nextInt(hero.lines.length)];
        player.sendMessage(Text.literal("§e" + hero.title + ": §f" + line), false);
        return ActionResult.SUCCESS;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }
}
