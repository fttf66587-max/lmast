package ru.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

public class DemodogEntity extends HostileEntity implements UpsideDownMob {
    public DemodogEntity(EntityType<? extends DemodogEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 10;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 22)
                .add(EntityAttributes.ATTACK_DAMAGE, 5)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.40)
                .add(EntityAttributes.FOLLOW_RANGE, 32);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.2, true));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.9));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 12f));
        goalSelector.add(4, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        targetSelector.add(3, new ActiveTargetGoal<>(this, CharacterEntity.class, true));
    }
}
