package ru.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** Векна: поднимает жертву в воздух (проклятие), бьёт ударной волной. */
public class VecnaEntity extends BossMonster {
    public VecnaEntity(EntityType<? extends VecnaEntity> type, World world) {
        super(type, world, BossBar.Color.RED);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 300)
                .add(EntityAttributes.ATTACK_DAMAGE, 12)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.ARMOR, 10)
                .add(EntityAttributes.FOLLOW_RANGE, 48)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.7));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 20f));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        targetSelector.add(3, new ActiveTargetGoal<>(this, CharacterEntity.class, true));
    }

    @Override
    protected void bossTick(ServerWorld world) {
        LivingEntity t = getTarget();
        if (t == null) return;
        // Проклятие Векны
        if (age % 160 == 0 && squaredDistanceTo(t) < 576) {
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 60, 1));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 160, 0));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 160, 0));
            world.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_BELL_USE, SoundCategory.HOSTILE, 3f, 0.5f);
        }
        // Ударная волна
        if (age % 400 == 0) {
            for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(12), x -> x.isAlive())) {
                p.damage(world, getDamageSources().magic(), 6f);
                p.takeKnockback(2.0, getX() - p.getX(), getZ() - p.getZ());
            }
            world.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.HOSTILE, 2f, 0.6f);
        }
    }
}
