package ru.strangerthings.entity;

public enum Hero {
    ELEVEN("Оди", 30, 4, 0.30, new String[]{"Друзья... не лгут.", "Эгго?", "Плохие... люди. Рядом.", "Дверь. Открыта."}),
    MIKE("Майк", 20, 3, 0.28, new String[]{"Оди, ты слышишь меня? Приём!", "Мы должны найти Уилла.", "Это не шутка, ребята!"}),
    STEVE("Стив", 30, 6, 0.30, new String[]{"Я просто присматриваю за детьми.", "Хорошая бита, а?", "Опять паршивый день в Хоукинсе."}),
    HOPPER("Хоппер", 40, 7, 0.27, new String[]{"Держитесь за мной.", "Ничего хорошего в этом городе.", "Мне нужен кофе. И Эгго для Оди."}),
    DUSTIN("Дастин", 20, 3, 0.29, new String[]{"Это как в D&D! Это Демогоргон!", "Надо проверить компас.", "Не называйте меня коротышкой!"}),
    WILL("Уилл", 20, 3, 0.28, new String[]{"Я чувствую его... Он рядом.", "Холодно... Он в тени.", "Мам, это не просто гирлянды..."}),
    LUCAS("Лукас", 22, 4, 0.30, new String[]{"У меня есть рогатка. Всё под контролем.", "Макс, ты в порядке?", "Я не боюсь... почти."});

    public final String title;
    public final float health;
    public final double damage, speed;
    public final String[] lines;

    Hero(String title, float health, double damage, double speed, String[] lines) {
        this.title = title; this.health = health; this.damage = damage; this.speed = speed; this.lines = lines;
    }
}
