package ru.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

public abstract class BossMonster extends HostileEntity implements UpsideDownMob {
    protected final ServerBossBar bar;

    protected BossMonster(EntityType<? extends BossMonster> type, World world, BossBar.Color color) {
        super(type, world);
        this.bar = new ServerBossBar(getDisplayName(), color, BossBar.Style.NOTCHED_10);
        this.experiencePoints = 200;
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bar.removePlayer(player);
    }

    @Override
    protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        bar.setPercent(getHealth() / getMaxHealth());
        bossTick(world);
    }

    protected abstract void bossTick(ServerWorld world);

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }
}
