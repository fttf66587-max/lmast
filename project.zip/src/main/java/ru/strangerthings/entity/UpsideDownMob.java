package ru.strangerthings.entity;

/** Маркер: существо из Изнанки (герои атакуют таких, рация их считает). */
public interface UpsideDownMob {}
