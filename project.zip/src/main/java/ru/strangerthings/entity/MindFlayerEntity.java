package ru.strangerthings.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.strangerthings.ModEntities;

/** Пожиратель разума: гигантский паукообразный босс, призывает демопсов и травит спорами. */
public class MindFlayerEntity extends BossMonster {
    public MindFlayerEntity(EntityType<? extends MindFlayerEntity> type, World world) {
        super(type, world, BossBar.Color.PURPLE);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 400)
                .add(EntityAttributes.ATTACK_DAMAGE, 14)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.24)
                .add(EntityAttributes.ARMOR, 8)
                .add(EntityAttributes.FOLLOW_RANGE, 48)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 24f));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        targetSelector.add(3, new ActiveTargetGoal<>(this, CharacterEntity.class, true));
    }

    @Override
    protected void bossTick(ServerWorld world) {
        // Споры
        if (age % 120 == 0) {
            for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(18), x -> x.isAlive())) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
            }
        }
        // Призыв демопсов (не более 6 рядом)
        if (age % 300 == 0 && getTarget() != null) {
            long n = world.getEntitiesByClass(DemodogEntity.class, getBoundingBox().expand(30), e -> true).size();
            if (n < 6) {
                for (int i = 0; i < 2; i++) {
                    BlockPos pos = getBlockPos().add(random.nextInt(9) - 4, 0, random.nextInt(9) - 4);
                    ModEntities.DEMODOG.spawn(world, pos, SpawnReason.MOB_SUMMONED);
                }
            }
        }
    }
}
