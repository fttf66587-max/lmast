package ru.strangerthings;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import ru.strangerthings.block.RiftBlock;
import ru.strangerthings.block.VoidPoolBlock;

import java.util.function.Function;

public final class ModBlocks {
    public static final Block RIFT = register("rift", RiftBlock::new,
            AbstractBlock.Settings.create().noCollision().nonOpaque().strength(2f).luminance(s -> 13).dropsNothing());
    public static final Block VOID_POOL = register("void_pool", VoidPoolBlock::new,
            AbstractBlock.Settings.create().strength(2f).luminance(s -> 15));
    public static final Block UPSIDE_FLESH = register("upside_flesh", Block::new,
            AbstractBlock.Settings.create().strength(1.5f).sounds(BlockSoundGroup.HONEY));
    public static final Block CHRISTMAS_LIGHTS = register("christmas_lights", Block::new,
            AbstractBlock.Settings.create().strength(0.5f).luminance(s -> 12).sounds(BlockSoundGroup.GLASS));

    private static <T extends Block> T register(String name, Function<AbstractBlock.Settings, T> factory, AbstractBlock.Settings settings) {
        RegistryKey<Block> key = RegistryKey.of(RegistryKeys.BLOCK, StrangerThings.id(name));
        T block = Registry.register(Registries.BLOCK, key, factory.apply(settings.registryKey(key)));
        RegistryKey<Item> ik = RegistryKey.of(RegistryKeys.ITEM, StrangerThings.id(name));
        BlockItem bi = Registry.register(Registries.ITEM, ik,
                new BlockItem(block, new Item.Settings().useBlockPrefixedTranslationKey().registryKey(ik)));
        ModItems.ALL.add(bi);
        return block;
    }

    public static void init() {}
}
