package ru.strangerthings;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;

public final class ModCommands {
    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
            dispatcher.register(CommandManager.literal("st")
                .then(CommandManager.literal("hawkins").executes(c -> { Hawkins.enter(c.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.literal("overworld").executes(c -> { Teleporter.toOverworld(c.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.literal("upsidedown").executes(c -> { Teleporter.toUpsideDown(c.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.literal("void").executes(c -> { Teleporter.toVoid(c.getSource().getPlayerOrThrow()); return 1; }))
            ));
    }
}
