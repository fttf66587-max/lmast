package ru.strangerthings;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public class StrangerThings implements ModInitializer {
    public static final String MOD_ID = "strangerthings";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.init();
        ModBlocks.init();
        ModItems.init();
        ModCommands.init();

        // При первом входе предлагаем выбрать, где начать игру
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (p.getCommandTags().contains("st_welcomed")) return;
            p.addCommandTag("st_welcomed");
            Text msg = Text.literal("Добро пожаловать в «Странные дела»! Где начнём?\n").formatted(Formatting.RED)
                    .append(button("[Хоукинс]", "/st hawkins"))
                    .append(Text.literal("   "))
                    .append(button("[Обычный мир]", "/st overworld"));
            p.sendMessage(msg, false);
        });
    }

    private static Text button(String label, String cmd) {
        return Text.literal(label).styled(s -> s.withColor(Formatting.GOLD).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd)));
    }
}
